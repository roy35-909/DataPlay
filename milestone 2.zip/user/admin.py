from django.contrib import admin

from .models import Instructor, Students,Mentor

admin.site.register(Instructor)
admin.site.register(Mentor)
# admin.site.register(Students)
